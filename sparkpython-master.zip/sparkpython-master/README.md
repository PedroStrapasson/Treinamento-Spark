### Treinamento Spark Streaming.

* Acessar a pasta do projeto
* Instalar a lib do vscode (Dev Containers ou Remote Development) e (Docker)
* Instalar a lib do vscode Jupyter notebook
* Baixar a imagem python3.7 
  ````bash
    docker pull python:3.7.15
  ````
* Criar container e Atachar volume no container
  ````bash
    docker run --net=host -it -v ${pwd}:/app --name spark-streaming python:3.7.15
  ````
* Configura o container
  ````bash
    docker start spark-streaming
    docker exec -it spark-streaming /bin/bash  | ou atachar no vscode

  #atualiza container 
  apt update
  apt upgrade -y
  apt install build-essential gcc make perl dkms curl tcl -y
  apt install -y build-essential zlib1g-dev libncurses5-dev libgdbm-dev libnss3-dev libssl-dev libsqlite3-dev libreadline-dev libffi-dev wget libbz2-dev libkrb5-dev
  
  #JDK
  #add repository debian test
  echo deb http://deb.debian.org/debian/ sid main | tee /etc/apt/sources.list.d/debian-sid.list
  apt-get update
  apt-get install -y openjdk-8-jdk

  #kerberos
  apt install -y krb5-user
  
  cp auth/krb5.conf /etc/krb5.conf
````

* Instalar libs para
  pip install -r client-listener/requirements.txt