from pyspark.sql import SparkSession
from krbcontext.context import krbContext
import os

with krbContext(using_keytab=True, principal='teste@KDC.CDP7', keytab_file='auth/teste.keytab'):
        pass

os.environ["SPARK_CONF_DIR"] = "resources"

spark = SparkSession.builder.master("local").appName("SparkStreaming").enableHiveSupport().getOrCreate()

spark.sql("show databases").show()

lines = spark.readStream\
    .format("socket")\
    .option("host", "localhost")\
    .option("port", 9009) \
    .load()

query = lines.writeStream \
    .outputMode("append") \
    .format("console") \
    .start()

query.awaitTermination()