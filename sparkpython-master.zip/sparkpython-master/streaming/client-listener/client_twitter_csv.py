from pyspark.sql import SparkSession
from krbcontext.context import krbContext
import os
import shutil

for item in ['./check', './csv']: 
    try: 
        shutil.rmtree(item)
    except OSError as err:
        print(f'Aviso: {err.sterror}')

with krbContext(using_keytab=True, principal='teste@KDC.CDP7', keytab_file='auth/teste.keytab'):
        pass

os.environ["SPARK_CONF_DIR"] = "resources"


spark = SparkSession.builder.master("local").appName("SparkStreaming").enableHiveSupport().getOrCreate()

#spark.sql("show databases").show()

tweets = spark.readStream\
    .format("socket")\
    .option("host", "localhost")\
    .option("port", 9009) \
    .load()

query = tweets.writeStream \
    .outputMode('append') \
        .option('encoding', 'utf-8')\
        .format('csv')\
        .option('path', './csv')\
        .option('checkpointLocation','./check')\
        .start()


query.awaitTermination()